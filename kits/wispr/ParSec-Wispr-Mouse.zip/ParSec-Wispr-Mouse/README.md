# ParSec Wispr Mouse

Talk to Wispr Flow with your mouse side buttons.

- Hold the back side button and speak. Release: Wispr Flow types what you said.
- Press the front side button: Enter (sends the message).
- Outside a text box both buttons keep their normal Back / Forward job.

Needs Windows 10 or 11 and a mouse with two side buttons.

## Install

1. Install Wispr Flow from wisprflow.ai and sign in (the free plan is enough). Keep its push-to-talk shortcut at the default `Ctrl + Win`.
2. Extract `ParSec-Wispr-Mouse.zip`.
3. Double-click `install.cmd`. If Windows shows "Windows protected your PC", click More info, then Run anyway.
   It installs AutoHotkey v2 with winget if missing (per user, no admin), copies the scripts to `%LOCALAPPDATA%\ParSec-Wispr-Mouse`, adds a Startup shortcut and starts it.
4. A green H icon near the clock means it is running.

Preview without changing anything: `powershell -ExecutionPolicy Bypass -File .\install.ps1 -WhatIf`

## Change the buttons

Open `%LOCALAPPDATA%\ParSec-Wispr-Mouse\wispr-mouse.ahk` in Notepad and edit the SETTINGS block at the top:

| setting | default | meaning |
|---|---|---|
| `TALK_BUTTON` | `"XButton1"` | hold to talk (`XButton1` back side button, `XButton2` front, `MButton` wheel click) |
| `SEND_BUTTON` | `"XButton2"` | press to send |
| `SEND_KEYS` | `"{Enter}"` | what "send" presses; `"^{Enter}"` = Ctrl+Enter |
| `WISPR_KEYS` | `["LCtrl", "LWin"]` | Wispr Flow's push-to-talk shortcut, if you changed it |
| `SMART_MODE` | `true` | `false` = buttons talk/send everywhere, not only in text boxes |

Save, then right-click the tray icon and choose Reload Script.

## Uninstall

Double-click `uninstall.cmd`. It stops the script, removes the Startup shortcut and the `ParSec-Wispr-Mouse` folder. AutoHotkey stays installed; remove it from Settings > Apps if you want.

## Troubleshooting

- A button goes Back inside a text box: that app hides its text box from Windows. Set `SMART_MODE := false`, or add the app's process name to `OPAQUE_PANE_PROCS` in `uia-focus.ahk`.
- Nothing gets typed: check Wispr Flow is running and its shortcut is `Ctrl + Win`.
- Wispr keeps listening after you release: press the button once more.

## Privacy and security

Plain-text scripts, read them before you run them. The script makes no network connections, writes no files, collects nothing. The only network use is winget downloading AutoHotkey during install, if it is missing.

## Files

- `wispr-mouse.ahk` - the button mapping (settings at the top)
- `uia-focus.ahk` - asks Windows UI Automation whether the focus is a text box (read-only)
- `install.cmd` / `install.ps1` - installer
- `uninstall.cmd` / `uninstall.ps1` - remover
