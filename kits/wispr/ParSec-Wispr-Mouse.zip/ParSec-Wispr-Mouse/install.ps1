# install.ps1 - ParSec Wispr Mouse installer (per-user, no admin needed).
#   1. Installs AutoHotkey v2 with winget if it is missing.
#   2. Copies the two scripts to %LOCALAPPDATA%\ParSec-Wispr-Mouse
#   3. Adds a shortcut to your Startup folder so it runs when Windows starts.
#   4. Starts it now.
# Undo everything with uninstall.cmd (or uninstall.ps1).
# Safe to run again. Preview without changing anything:  .\install.ps1 -WhatIf
[CmdletBinding(SupportsShouldProcess = $true)]
param(
    [string]$InstallDir = (Join-Path $env:LOCALAPPDATA 'ParSec-Wispr-Mouse'),
    [string]$StartupDir = [Environment]::GetFolderPath('Startup'),
    [switch]$NoLaunch
)
$ErrorActionPreference = 'Stop'
$src   = $PSScriptRoot
$files = @('wispr-mouse.ahk', 'uia-focus.ahk')
$lnk   = Join-Path $StartupDir 'ParSec Wispr Mouse.lnk'

foreach ($f in $files) {
    if (-not (Test-Path (Join-Path $src $f))) { throw "Missing $f next to install.ps1 - unzip the whole folder first." }
}

# 1. AutoHotkey v2
function Find-Ahk {
    $exe = if ([Environment]::Is64BitOperatingSystem) { 'AutoHotkey64.exe' } else { 'AutoHotkey32.exe' }
    $dirs = @("$env:ProgramFiles\AutoHotkey", "$env:LOCALAPPDATA\Programs\AutoHotkey")
    foreach ($key in 'HKCU:\SOFTWARE\AutoHotkey', 'HKLM:\SOFTWARE\AutoHotkey') {
        $d = (Get-ItemProperty $key -ErrorAction SilentlyContinue).InstallDir
        if ($d) { $dirs = @($d) + $dirs }
    }
    foreach ($d in $dirs) {
        $p = Join-Path $d "v2\$exe"
        if (Test-Path $p) { return $p }
    }
    return $null
}

$ahk = Find-Ahk
if (-not $ahk) {
    if (-not $PSCmdlet.ShouldProcess('AutoHotkey v2', 'Install with winget')) {
        $ahk = '<AutoHotkey v2 - would be installed>'
    } else {
        if (-not (Get-Command winget -ErrorAction SilentlyContinue)) {
            throw 'AutoHotkey v2 is missing and winget is not available. Install AutoHotkey v2 from https://www.autohotkey.com then run this again.'
        }
        Write-Host 'Installing AutoHotkey v2 (winget)...'
        winget install --id AutoHotkey.AutoHotkey -e --scope user --silent --accept-source-agreements --accept-package-agreements
        $ahk = Find-Ahk
        if (-not $ahk) {
            winget install --id AutoHotkey.AutoHotkey -e --silent --accept-source-agreements --accept-package-agreements
            $ahk = Find-Ahk
        }
        if (-not $ahk) { throw 'AutoHotkey install failed. Install AutoHotkey v2 from https://www.autohotkey.com then run this again.' }
    }
}
Write-Host "AutoHotkey: $ahk"

# 2. Copy the scripts
$target = Join-Path $InstallDir 'wispr-mouse.ahk'
if ($PSCmdlet.ShouldProcess($InstallDir, 'Copy wispr-mouse.ahk + uia-focus.ahk')) {
    New-Item -ItemType Directory -Force $InstallDir | Out-Null
    foreach ($f in $files) { Copy-Item (Join-Path $src $f) $InstallDir -Force }
}

# 3. Run at Windows start
if ($PSCmdlet.ShouldProcess($lnk, 'Create Startup shortcut')) {
    New-Item -ItemType Directory -Force $StartupDir | Out-Null
    $s = (New-Object -ComObject WScript.Shell).CreateShortcut($lnk)
    $s.TargetPath = $ahk
    $s.Arguments = "`"$target`""
    $s.WorkingDirectory = $InstallDir
    $s.Description = 'ParSec Wispr Mouse'
    $s.Save()
}

# 4. Start now
if (-not $NoLaunch -and $PSCmdlet.ShouldProcess($target, 'Start')) {
    Start-Process -FilePath $ahk -ArgumentList "`"$target`"" -WorkingDirectory $InstallDir
}

$wispr = (Test-Path "$env:LOCALAPPDATA\WisprFlow") -or (Get-Process -Name 'Wispr Flow' -ErrorAction SilentlyContinue)
if (-not $wispr) { Write-Warning 'Wispr Flow does not seem to be installed yet. Get it from https://wisprflow.ai and sign in.' }

Write-Host ''
if ($WhatIfPreference) { Write-Host 'Preview only - nothing was changed.'; return }
Write-Host 'Done. Look for the green H icon near the clock = running.'
Write-Host 'Click inside any text box: hold the back side button and talk, release, then press the front side button to send.'
