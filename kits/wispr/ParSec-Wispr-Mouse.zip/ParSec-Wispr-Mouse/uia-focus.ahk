#Requires AutoHotkey v2.0
; uia-focus.ahk - "is the keyboard focus inside a text box?"
; Asks Windows UI Automation (built into Windows, no extra libraries) what has focus.
; Read-only: it only looks at the focused control, it never changes anything.

global _UIA := 0

_UIAObj() {
    global _UIA
    if !_UIA
        _UIA := ComObject("{ff48dba4-60ef-4201-aa87-54103eef594e}", "{30cbe57d-d9d0-452a-ab13-7ac5ac4825ee}") ; CUIAutomation / IUIAutomation
    return _UIA
}

; IUIAutomationElement::GetCurrentPropertyValue (vtable 10) -> unpack VARIANT
_UIAProp(el, id) {
    v := Buffer(24, 0)
    ComCall(10, el, "int", id, "ptr", v)
    vt := NumGet(v, 0, "ushort")
    switch vt {
        case 3:  r := NumGet(v, 8, "int")                   ; VT_I4
        case 11: r := NumGet(v, 8, "short") ? 1 : 0          ; VT_BOOL
        case 8:  r := StrGet(NumGet(v, 8, "ptr"), "UTF-16")  ; VT_BSTR
        case 0:  r := ""                                     ; VT_EMPTY
        default: r := "vt" vt
    }
    DllCall("oleaut32\VariantClear", "ptr", v)
    return r
}

; Describes the focused UIA element (+ classic win32 caret handle).
FocusInfo() {
    info := Map("ct", 0, "valAvail", 0, "ro", -1, "textEdit", 0, "pid", 0, "proc", "", "caret", 0)
    try {
        el := 0
        ComCall(8, _UIAObj(), "ptr*", &el)   ; IUIAutomation::GetFocusedElement
        if el {
            try info["ct"]       := _UIAProp(el, 30003)  ; ControlType
            try info["valAvail"] := _UIAProp(el, 30043)  ; IsValuePatternAvailable
            try info["ro"]       := _UIAProp(el, 30046)  ; ValueIsReadOnly
            try info["textEdit"] := _UIAProp(el, 30149)  ; IsTextEditPatternAvailable
            try info["pid"]      := _UIAProp(el, 30002)  ; ProcessId
            ObjRelease(el)
        }
    }
    try info["proc"] := ProcessGetName(info["pid"])
    ; GUITHREADINFO: cbSize, flags, then 6 window handles (hwndCaret is the 6th) + RECT
    size := 8 + 6 * A_PtrSize + 16
    gti := Buffer(size, 0)
    NumPut("uint", size, gti, 0)
    if DllCall("GetGUIThreadInfo", "uint", 0, "ptr", gti)
        info["caret"] := NumGet(gti, 8 + 5 * A_PtrSize, "ptr")
    return info
}

; Apps whose message box is invisible to UI Automation (focus lands on a bare Pane).
; Process name in lowercase. If a button does Back inside some app's text box, add that app here.
global OPAQUE_PANE_PROCS := Map(
    "whatsapp.root.exe", 1,
    "whatsapp.exe",      1
)

; Terminal apps: every key goes to the prompt, so treat them as a text box.
global TERMINAL_PROCS := Map(
    "windowsterminal.exe", 1,
    "openconsole.exe",     1,
    "conhost.exe",         1,
    "wezterm-gui.exe",     1,
    "alacritty.exe",       1,
    "mintty.exe",          1
)

; Decision rule:
;   Edit (50004)      : text inputs, address bars, chat boxes          -> yes unless read-only
;   Document (50030)  : Notepad-style editor -> yes; read-only web page -> no
;   TextEdit pattern  : web "contenteditable" chat boxes               -> yes unless read-only
;   Pane (50033)      : apps listed in OPAQUE_PANE_PROCS                -> yes
;   win32 caret       : classic Windows edit controls                   -> yes
;   anything else (web page, file list, buttons)                        -> no
IsTextField(&why := "") {
    i := FocusInfo()
    proc := StrLower(i["proc"])
    ct := i["ct"]
    if TERMINAL_PROCS.Has(proc) {
        why := "terminal"
        return true
    }
    explicitRO := (i["valAvail"] && i["ro"] == 1)
    if (ct == 50033 && OPAQUE_PANE_PROCS.Has(proc)) {
        why := "opaque-pane"
        return true
    }
    if (ct == 50004) {
        why := "edit"
        return !explicitRO
    }
    if (ct == 50030) {
        why := "document"
        return i["valAvail"] && i["ro"] == 0
    }
    if (i["textEdit"] && !explicitRO) {
        why := "textedit"
        return true
    }
    if (i["caret"]) {
        why := "caret"
        return true
    }
    why := "other"
    return false
}
