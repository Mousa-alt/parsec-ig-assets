# uninstall.ps1 - removes ParSec Wispr Mouse: stops it, deletes the Startup shortcut and the
# %LOCALAPPDATA%\ParSec-Wispr-Mouse folder. AutoHotkey itself stays installed; remove it from
# Settings > Apps if you want. Preview without changing anything:  .\uninstall.ps1 -WhatIf
[CmdletBinding(SupportsShouldProcess = $true)]
param(
    [string]$InstallDir = (Join-Path $env:LOCALAPPDATA 'ParSec-Wispr-Mouse'),
    [string]$StartupDir = [Environment]::GetFolderPath('Startup')
)
$ErrorActionPreference = 'Stop'
$lnk    = Join-Path $StartupDir 'ParSec Wispr Mouse.lnk'
$target = Join-Path $InstallDir 'wispr-mouse.ahk'

# Safety: only ever delete a folder that is ours.
if ((Split-Path $InstallDir -Leaf) -ne 'ParSec-Wispr-Mouse') {
    throw "Refusing to delete '$InstallDir' - the folder name must be ParSec-Wispr-Mouse."
}

# 1. Stop the running copy (only the AutoHotkey process running OUR script)
$wi = $WhatIfPreference; $WhatIfPreference = $false   # reading the process list is not a change
$procs = Get-CimInstance Win32_Process -Filter "Name LIKE 'AutoHotkey%'" |
    Where-Object { $_.CommandLine -and $_.CommandLine.IndexOf($target, [StringComparison]::OrdinalIgnoreCase) -ge 0 }
$WhatIfPreference = $wi
foreach ($p in $procs) {
    if ($PSCmdlet.ShouldProcess("PID $($p.ProcessId)", 'Stop ParSec Wispr Mouse')) {
        Stop-Process -Id $p.ProcessId -Force -ErrorAction SilentlyContinue
    }
}

# 2. Startup shortcut
if ((Test-Path $lnk) -and $PSCmdlet.ShouldProcess($lnk, 'Delete Startup shortcut')) {
    Remove-Item $lnk -Force
}

# 3. Script folder
if ((Test-Path $InstallDir) -and $PSCmdlet.ShouldProcess($InstallDir, 'Delete folder')) {
    Start-Sleep -Milliseconds 500
    Remove-Item $InstallDir -Recurse -Force
}

if ($WhatIfPreference) { Write-Host 'Preview only - nothing was changed.' }
else { Write-Host 'Removed. Your mouse buttons are back to normal.' }
