#Requires AutoHotkey v2.0
#SingleInstance Force
; ParSec Wispr Mouse - talk to Wispr Flow with your mouse side buttons.
;
;   Hold TALK_BUTTON  -> Wispr Flow listens while you hold it. Release -> your words are typed.
;   Press SEND_BUTTON -> Enter (sends the message).
;
; Outside a text box (web page, file list) both buttons keep their normal Back / Forward job,
; unless you set SMART_MODE := false below.
;
; This script makes no network connections, writes no files and collects nothing.

; ============================ SETTINGS (edit, save, then right-click the tray icon > Reload) ===
; Mouse button names: "XButton1" = back side button, "XButton2" = front side button,
; "MButton" = wheel click. To swap the two side buttons, swap the two values.
TALK_BUTTON := "XButton1"
SEND_BUTTON := "XButton2"

; What the send button presses. "{Enter}" for most chats; "^{Enter}" = Ctrl+Enter.
SEND_KEYS := "{Enter}"

; Wispr Flow's push-to-talk shortcut. Default in Wispr Flow on Windows is Ctrl + Win.
; If you changed it inside Wispr Flow, list the same keys here, e.g. ["LCtrl", "LAlt"].
WISPR_KEYS := ["LCtrl", "LWin"]

; true  = buttons talk/send only when the cursor is in a text box; elsewhere they stay Back/Forward.
; false = buttons always talk/send, everywhere.
SMART_MODE := true
; ==============================================================================================

#Include uia-focus.ahk
Persistent
SendMode "Input"
SetKeyDelay -1, -1
A_IconTip := "ParSec Wispr Mouse"
A_MenuMaskKey := "vkE8"   ; unassigned key: stops a released Win key from opening the Start menu

global HOLDING := false     ; true while the Wispr keys are held down by this script
global HOLD_START := 0
global MAX_HOLD_MS := 600000  ; safety: never hold the Wispr keys longer than 10 minutes

Hotkey "*" TALK_BUTTON, TalkDown
Hotkey "*" TALK_BUTTON " up", TalkUp
Hotkey "*" SEND_BUTTON, SendPress
OnExit ReleaseWispr

InTextBox() {
    if !SMART_MODE
        return true
    isText := false
    try isText := IsTextField()
    return isText
}

TalkDown(*) {
    global HOLDING, HOLD_START
    if HOLDING                       ; key repeat / double fire while already holding
        return
    if !InTextBox() {
        Send "{Blind}{" TALK_BUTTON "}"   ; not a text box: keep the button's normal job
        return
    }
    keys := ""
    for k in WISPR_KEYS
        keys .= "{" k " down}"
    Send "{Blind}" keys
    HOLDING := true
    HOLD_START := A_TickCount
    SetTimer WatchRelease, 100
}

TalkUp(*) {
    ReleaseWispr()
}

ReleaseWispr(*) {
    global HOLDING
    if !HOLDING
        return
    HOLDING := false
    SetTimer WatchRelease, 0
    keys := ""
    i := WISPR_KEYS.Length
    while i >= 1 {                   ; release in reverse order, like a person would
        keys .= "{" WISPR_KEYS[i] " up}"
        i--
    }
    Send "{Blind}" keys
}

; If the button-up event is ever missed, release the keys anyway so nothing stays stuck.
WatchRelease() {
    if !HOLDING
        return
    if !GetKeyState(TALK_BUTTON, "P") || (A_TickCount - HOLD_START > MAX_HOLD_MS)
        ReleaseWispr()
}

SendPress(*) {
    if HOLDING {                     ; pressed while still talking: just stop listening, send nothing
        ReleaseWispr()               ; (Enter with the Wispr keys still down would be a different shortcut)
        return
    }
    if InTextBox()
        Send SEND_KEYS
    else
        Send "{Blind}{" SEND_BUTTON "}"
}
